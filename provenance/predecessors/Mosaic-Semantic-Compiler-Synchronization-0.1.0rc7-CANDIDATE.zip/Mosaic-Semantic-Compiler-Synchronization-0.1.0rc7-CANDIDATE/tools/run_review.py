"""Deterministic clean-process review runner.

R2: the rooted review record must be reproducible on any host. The interpreter
path is therefore normalized to a placeholder before rooting, and the real
environment is recorded in a non-rooted block. Elapsed times are normalized in
captured output, following the convention already used in the shipped records.
"""
from __future__ import annotations

import hashlib
import json
import platform
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
INTERPRETER = "<interpreter>"
SCHEMA = "semcrys.synchronization-clean-review.v0.2"

CHECKS = (
    (["-m", "unittest", "discover", "-s", "tests"], "full"),
    (["-m", "unittest", "tests.test_synchronization", "-v"], "full"),
    (["-m", "semcrys", "verify-self"], "full"),
    (["-m", "semcrys", "capabilities"], "full"),
    (["-m", "unittest", "discover", "-s", "tests"], "lite/source"),
    (["-m", "semcrys_lite", "demo"], "lite/source"),
    (["-m", "semcrys", "synchronize", "disclosure", "fixtures/sample.txt", "fixtures/accounting-size-stub.leg"], "."),
    (["-m", "semcrys", "synchronize", "ordering", "fixtures/sample.txt", "fixtures/accounting-size-stub.leg"], "."),
    (["-m", "semcrys", "synchronize", "compose", "fixtures/sample.txt", "fixtures/accounting-size-stub.leg", "--minimum-count", "2"], "."),
    (["-m", "semcrys", "synchronize", "account", "--source", "fixtures/sample.txt",
      "--container", "fixtures/accounting-size-stub.crys", "--legend", "fixtures/accounting-size-stub.leg"], "."),
)

_ELAPSED = re.compile(r"in \d+\.\d+s")
_FLOAT = re.compile(r"\b\d+\.\d{3,}\b")


def canonical(value) -> bytes:
    return json.dumps(value, ensure_ascii=True, sort_keys=True, separators=(",", ":")).encode("utf-8")


def normalize(text: str) -> str:
    text = _ELAPSED.sub("in <elapsed>", text)
    text = _FLOAT.sub("<float>", text)
    return text.replace("\r\n", "\n")


def subject_root() -> str:
    return json.loads((ROOT / "evidence" / "SUBJECT.json").read_text(encoding="utf-8"))["subject_root"]


def run(review_id: int) -> dict:
    checks = []
    for arguments, cwd in CHECKS:
        workdir = ROOT / cwd
        env_path = str(ROOT / "full") + ":" + str(ROOT / "lite" / "source")
        completed = subprocess.run(
            [sys.executable, *arguments],
            cwd=workdir, capture_output=True, text=True,
            env={"PYTHONPATH": env_path, "PATH": "/usr/bin:/bin", "PYTHONDONTWRITEBYTECODE": "1"},
        )
        out, err = normalize(completed.stdout), normalize(completed.stderr)
        checks.append({
            # Rooted fields carry no host-specific value.
            "command": [INTERPRETER, *arguments],
            "working_directory": cwd,
            "returncode": completed.returncode,
            "stdout_sha256": hashlib.sha256(out.encode()).hexdigest(),
            "stderr_sha256": hashlib.sha256(err.encode()).hexdigest(),
            "stdout_tail": out[-1200:],
            "stderr_tail": err[-1200:],
        })
    record = {
        "schema": SCHEMA,
        "standing": "CANDIDATE_ONLY",
        "review": review_id,
        "subject_root": subject_root(),
        "path_normalization": "INTERPRETER_AND_ABSOLUTE_PATHS_EXCLUDED_FROM_ROOT",
        "checks": checks,
        "status": "PASS" if all(c["returncode"] == 0 for c in checks) else "FAIL",
        "independent_acceptance": False,
        "security_claim": "NONE",
    }
    record["review_root"] = hashlib.sha256(canonical(record)).hexdigest()
    # Host detail is retained but deliberately outside the rooted object.
    record["environment_not_rooted"] = {
        "platform": platform.system(),
        "python_version": platform.python_version(),
        "interpreter_recorded": False,
    }
    return record


if __name__ == "__main__":
    identifier = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    result = run(identifier)
    (ROOT / "evidence" / f"REVIEW_{identifier}.json").write_text(
        json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8"
    )
    print(json.dumps({"review": identifier, "status": result["status"],
                      "review_root": result["review_root"]}, indent=2, sort_keys=True))
