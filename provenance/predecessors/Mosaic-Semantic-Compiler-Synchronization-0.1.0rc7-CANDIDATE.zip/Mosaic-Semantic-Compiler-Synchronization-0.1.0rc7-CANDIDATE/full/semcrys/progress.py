"""Presentation only: full event receipts remain in operation results."""
import json
import sys

def emit(event, mode='full'):
    if mode == 'quiet': return
    if mode == 'full':
        print(json.dumps(event,ensure_ascii=True,sort_keys=True),file=sys.stderr,flush=True)
        return
    if mode != 'summary': raise ValueError('HELD_PROGRESS_MODE')
    summary={k:event[k] for k in ('stage','operation','status','code') if k in event}
    config=event.get('effective_configuration',{})
    if 'instance_constitution_sha256' in config:
        summary['instance_constitution_sha256']=config['instance_constitution_sha256']
    print(json.dumps(summary,ensure_ascii=True,sort_keys=True),file=sys.stderr,flush=True)
