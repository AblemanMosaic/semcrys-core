"""Machine-readable installed CLI contract, derived from the actual parser."""
import argparse
import hashlib
from pathlib import Path
from .integrity import catalogue
from streaming_legend.core import canonical

READ_ONLY_COMMANDS={'fold audit','fold delivery-cost','assembly inspect','recovery inspect','recovery directory-inspect',
 'archaic profiles','archaic plan','transport capabilities','transport negotiate','transport frame','transport verify-frame',
 'gtk capabilities','gtk analyze','gtk verify-vocabulary','workbench status','workbench export',
 'synchronize disclosure','synchronize ordering','synchronize compose','synchronize account'}

def _scalar(value):
    if isinstance(value,Path): return str(value)
    if value is argparse.SUPPRESS: return None
    return value

def surface():
    # Imported lazily: the CLI imports this module to dispatch the command.
    from .cli import parser
    commands=[]
    def visit(node,path):
        children=[a for a in node._actions if isinstance(a,argparse._SubParsersAction)]
        if children:
            for action in children:
                for name,child in sorted(action.choices.items()): visit(child,path+[name])
            return
        arguments=[]
        for action in node._actions:
            if isinstance(action,argparse._HelpAction): continue
            arguments.append({'destination':action.dest,'flags':list(action.option_strings),
                'positional':not bool(action.option_strings),'required':bool(action.required),
                'nargs':action.nargs,'default':_scalar(action.default),'choices':list(action.choices) if action.choices is not None else None,
                'value_type':'boolean' if isinstance(action,(argparse._StoreTrueAction,argparse._StoreFalseAction)) else getattr(action.type,'__name__','string'),
                'repeatable':isinstance(action,argparse._AppendAction)})
        command=' '.join(path)
        commands.append({'semantic_slug':'semcrys.cli.'+'.'.join(path),'command':command,'arguments':arguments,
            'effect':'READ_ONLY' if path[0] in ('verify-self','profiles','capabilities','formats','plan','inspect') or command in READ_ONLY_COMMANDS else 'EXPLICIT_LOCAL_OUTPUT'})
    visit(parser(),[])
    profiles=catalogue()
    from .formats import registry
    from .release_scope import load as release_scope
    result={'schema':'semcrys.installed-capability-surface.v0.1','standing':'CANDIDATE_ONLY',
        'commands':commands,'profiles':profiles,'release_scope':release_scope(commands),'abi_registry_root':registry()['registry_root'],'abi_registry_command':'formats',
        'configuration_funnel':{
            'S':'DECLARED_PHASE_SPACE_INCLUDING_EXPLICITLY_UNAVAILABLE_MECHANISMS',
            'CM1':'FUNCTIONAL_PRECONDITIONS_PROFILE_DEPENDENCIES_FORMAT_AND_LIMITS',
            'CM2':'USER_CHOICE_OR_EXACT_SOURCE_MEASURED_COST_NOT_GLOBAL_OPTIMALITY',
            'IC':'ROOTED_EFFECTIVE_CONFIGURATION_BEFORE_REALIZATION',
            'IR':'ACTUAL_REALIZATION_AND_RECONSTRUCTION_RECEIPT'},
        'format_family':{'.crys':'ENCODED_CONTAINER_ABI_0.2_WITH_EXPLICIT_CRITICAL_FEATURES','.leg':'BINARY_LEGEND_ABI_0.2_OR_FOLD_PROJECTION_ABI_0.1_RICH_0.2_COMPACT','.gly':'GLYPH_REGISTRY_ABI_0.1'},
        'admission_effect':'NONE','authority_effect':'NONE','release_ready':False,
        'capability_listing_is_not_proof_of_all_option_combinations':True}
    result['surface_root']=hashlib.sha256(canonical(result)).hexdigest()
    return result
