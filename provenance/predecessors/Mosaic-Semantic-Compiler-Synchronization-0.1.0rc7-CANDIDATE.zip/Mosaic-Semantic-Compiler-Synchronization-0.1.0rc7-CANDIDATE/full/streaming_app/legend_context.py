"""Ephemeral, explicit verified legend sessions; never a persistent trust cache.

SPDX-License-Identifier: Apache-2.0
Structural validation and value uniqueness run once per exact snapshot. Every
operation checks full snapshot AND derived lookup hashes, not mtime-as-custody.
The owner process and its private memory are trusted; malicious same-process
code and OS compromise are not addressed by these checks.
"""
from streaming_legend import scratch_io as sio
import hashlib
import sqlite3
import tempfile
import time
import inspect
import os
from functools import wraps
from contextlib import contextmanager
from pathlib import Path
from streaming_legend.assembly import ExecutionLegendReader as LegendReader
from streaming_legend.core import canonical, file_sha256
from streaming_legend.cache import SharedLookupCache

def refuse(code):
    from .core import Refusal
    raise Refusal(code)

def governed_context(function):
    @wraps(function)
    def run(*args,**kwargs):
        context=kwargs.get('legend_context')
        if context is None:
            with VerifiedLegendContext() as context:
                return run(*args,**{**kwargs,'legend_context':context})
        if type(context) is not VerifiedLegendContext: refuse('HELD_CONTEXT_TYPE')
        # Keep the user destination untouched until *all* context exit guards
        # have passed. Inner encode/decode publication targets only this stage.
        from .core import protect_outputs
        bound=inspect.signature(function).bind(*args,**kwargs); bound.apply_defaults()
        target=Path(bound.arguments['output'])
        inputs=[bound.arguments['source'],*bound.arguments.get('external_legends',()),*context.protected_paths()]
        glyph=bound.arguments.get('glyph_registry')
        if glyph is not None: inputs.append(glyph)
        front=bound.arguments.get('fold_front')
        if front is not None: inputs.append(front)
        inputs.extend(bound.arguments.get('additional_sources',()))
        try:
            protect_outputs([target],inputs)
            target.parent.mkdir(parents=True,exist_ok=True)
            # Nested internal decode runs must not exhaust Windows MAX_PATH
            # merely because the user's workspace has a descriptive name.
            with sio.TempDirectory(prefix='sc-',dir=target.parent) as name:
                stage=Path(name)/('result'+target.suffix); bound.arguments['output']=stage
                with context.operation(): result=function(*bound.args,**bound.kwargs)
                result={**result,'execution_context':context.receipt()}
                sio.replace(stage,target)
            return result
        except BaseException:
            context._poisoned=True
            raise
    return run

class _Cursor:
    def __init__(self,row): self.row=row
    def fetchone(self): return self.row

def invalidates_on_failure(function):
    @wraps(function)
    def run(self,*args,**kwargs):
        try: return function(self,*args,**kwargs)
        except BaseException:
            self._poisoned=True
            raise
    return run

class StackLookup:
    def __init__(self,rows): self.rows=rows
    def execute(self,query,params):
        if query not in ('SELECT id FROM lookup WHERE value=?','SELECT 1 FROM lookup WHERE value=?') or len(params)!=1:
            refuse('HELD_CONTEXT_QUERY_UNAVAILABLE')
        offset=0
        for row in self.rows:
            found=row['connection'].execute('SELECT id FROM lookup WHERE value=?',params).fetchone()
            if found: return _Cursor((offset+found[0],) if query.startswith('SELECT id') else (1,))
            offset+=row['entries']
        return _Cursor(None)
    def close(self): pass  # connection ownership belongs to the context

class VerifiedLegendContext:
    def __init__(self,*,max_legend_bytes=1024*1024*1024,max_legends=1024,progress=None,
                 max_lookup_cache_bytes=8*1024*1024,max_lookup_cache_entries=32768,
                 sqlite_cache_budget_kib=16384, lookup_backend='DISK',
                 backend_payload_budget_bytes=512*1024*1024, mmap_limit_bytes=256*1024*1024):
        if lookup_backend not in ('DISK','MMAP','RAM'): refuse('HELD_LOOKUP_BACKEND')
        if type(backend_payload_budget_bytes) is not int or backend_payload_budget_bytes<0: refuse('HELD_BACKEND_PAYLOAD_BUDGET')
        if type(mmap_limit_bytes) is not int or not 0<mmap_limit_bytes<=1<<30: refuse('HELD_BACKEND_MMAP_LIMIT')
        self.lookup_backend=lookup_backend; self.backend_budget=backend_payload_budget_bytes
        self.backend_used=0; self.mmap_limit=mmap_limit_bytes
        if type(max_legend_bytes) is not int or not 0<=max_legend_bytes<=1<<40 or type(max_legends) is not int or not 1<=max_legends<=4096:
            refuse('HELD_CONTEXT_LIMIT')
        self.maximum=max_legend_bytes; self.max_legends=max_legends; self.progress=progress
        self.lookup_cache=SharedLookupCache(max_lookup_cache_bytes,max_lookup_cache_entries)
        if type(sqlite_cache_budget_kib) is not int or not 4*max_legends<=sqlite_cache_budget_kib<=1<<30:
            refuse('HELD_CONTEXT_SQLITE_CACHE_BUDGET')
        self.sqlite_cache_budget_kib=sqlite_cache_budget_kib; self._sqlite_share_kib=0
        self.configuration={'schema':'semcrys.verified-context-instance.v0.1','standing':'CANDIDATE_ONLY',
            'policy':'EPHEMERAL_PROCESS_OWNED_SNAPSHOTS_FULL_HASH_GUARDS','max_legend_bytes':max_legend_bytes,'max_legends':max_legends,
            'lookup_cache_max_bytes':max_lookup_cache_bytes,'lookup_cache_max_entries':max_lookup_cache_entries,
            'sqlite_cache_budget_kib':sqlite_cache_budget_kib,'sqlite_cache_budget_kind':'AGGREGATE_SUGGESTED_PAGE_CACHE_NOT_RSS_LIMIT',
            'operation_sequence':['ROOT_SNAPSHOT','VALIDATE_STRUCTURE','BUILD_UNIQUE_LOOKUP','HASH_GUARD_REUSE','VERIFY_RECONSTRUCTION','HASH_GUARD_BEFORE_PUBLISH'],
            'persistent_cache':False,'security_claim':'NONE'}
        if lookup_backend!='DISK':
            self.configuration['physical_lookup']={'backend':lookup_backend,'standing':'CANDIDATE_ONLY',
              'unit_mode':'TOKEN_ONLY','payload_budget_bytes':backend_payload_budget_bytes,'mmap_limit_bytes':mmap_limit_bytes,
              'scope':'EXPLICIT_LOW_LEVEL_CONTEXT_ONLY','hard_rss_limit':False,'transported_configuration_changed':False}
        self.configuration['instance_constitution_sha256']=hashlib.sha256(canonical(self.configuration)).hexdigest()
        if progress: progress({'stage':'CONTEXT_INSTANCE_COMPILED','effective_configuration':self.configuration})
        self._temporary=sio.TempDirectory(prefix='semcrys-verified-context-')
        self._directory=Path(self._temporary.name); self._rows={}; self._stacks=set(); self._closed=False
        self._active=0; self._used=set(); self._source_paths=set(); self._poisoned=False
        self.stats={'full_validations':0,'lookup_builds':0,'snapshot_bytes':0,'guard_checks':0,'operations':0,'prepare_seconds':0.0}
    def __enter__(self): self._check(); return self
    def _check(self):
        if self._closed or self._poisoned: refuse('HELD_CONTEXT_CLOSED_OR_INVALID')
    def __exit__(self,*exc): self.close()
    def close(self):
        # Closed means unusable, not necessarily cleaned. A later explicit close
        # may retry owned cleanup after a lock/quota problem is removed.
        self._closed=True
        failures=[]
        for row in self._rows.values():
            if 'backend' in row:
                try: row['reader'].close()
                except BaseException as exc: failures.append(type(exc).__name__)
            try: row['connection'].close()
            except BaseException as exc: failures.append(type(exc).__name__)
        self.lookup_cache.clear()
        if not failures:
            try: self._temporary.cleanup()
            except BaseException as exc: failures.append(type(exc).__name__)
        if failures:
            from .core import Refusal
            raise Refusal('HELD_CONTEXT_CLEANUP_INCOMPLETE',str(self._directory)+': '+','.join(failures))
    def protected_paths(self): return list(self._source_paths)+[r['path'] for r in self._rows.values()]+[r['database'] for r in self._rows.values()]
    def _guard(self,row):
        self._check()
        if file_sha256(row['path'])!=row['sha256'] or file_sha256(row['database'])!=row['database_sha256']:
            self._poisoned=True; refuse('HELD_CONTEXT_CUSTODY_CHANGED')
        row['reader']._check_snapshot(); self.stats['guard_checks']+=1
    @contextmanager
    def operation(self):
        self._check(); outer=self._active==0
        if outer: self._used=set(); self.stats['operations']+=1
        self._active+=1
        try:
            yield self
            if outer:
                for root in sorted(self._used): self._guard(self._rows[root])
        except BaseException:
            self._poisoned=True
            raise
        finally: self._active-=1
    @invalidates_on_failure
    def prepare(self,path):
        self._check(); path=Path(path); self._source_paths.add(path.resolve())
        root=file_sha256(path)
        if root not in self._rows:
            if len(self._rows)>=self.max_legends or path.stat().st_size>self.maximum-self.stats['snapshot_bytes']:
                refuse('HELD_CONTEXT_LEGEND_BUDGET')
            started=time.perf_counter()
            if self.progress: self.progress({'stage':'LEGEND_CONTEXT_PREPARE','legend_sha256':root})
            # Identity is the full root in _rows and the verified content,
            # not the temporary filename. Compact private names avoid adding
            # 64 characters to an already long Windows temporary directory.
            local_name=f'{len(self._rows):04x}'
            target=self._directory/(local_name+'.leg'); digest=hashlib.sha256(); size=0
            with path.open('rb') as incoming,sio.open_output(target,'wb') as outgoing:
                for chunk in iter(lambda:incoming.read(1048576),b''):
                    size+=len(chunk)
                    if size>self.maximum-self.stats['snapshot_bytes']: refuse('HELD_CONTEXT_LEGEND_BUDGET')
                    digest.update(chunk); outgoing.write(chunk)
            if digest.hexdigest()!=root: refuse('HELD_CONTEXT_SOURCE_CHANGED')
            reader=LegendReader(target,lookup_cache=self.lookup_cache); verified=reader.verify(check_duplicates=False)
            if verified['sha256']!=root: refuse('HELD_CONTEXT_SOURCE_CHANGED')
            # Rebalance before opening the new builder, including it in the
            # aggregate target. SQLite targets do not bound its total allocations.
            share=min(2048,self.sqlite_cache_budget_kib//(len(self._rows)+1))
            for existing in self._rows.values(): existing['connection'].execute(f'PRAGMA cache_size=-{share}')
            self._sqlite_share_kib=share
            db=self._directory/(local_name+'.sqlite3'); connection=sio.sqlite_connect(db,capacity_bytes=max(65536,min(sio.DB_CAP,8*size+65536)))
            try:
                connection.execute('PRAGMA journal_mode=OFF'); connection.execute('PRAGMA synchronous=OFF')
                connection.execute('PRAGMA temp_store=FILE'); connection.execute(f'PRAGMA cache_size=-{share}')
                connection.execute('CREATE TABLE lookup(value BLOB PRIMARY KEY,id INTEGER NOT NULL) WITHOUT ROWID')
                try: connection.executemany('INSERT INTO lookup(value,id) VALUES (?,?)',((value,i) for i,value in reader.iter_values()))
                except sqlite3.IntegrityError: refuse('HELD_DUPLICATE_LEGEND_VALUE')
                connection.commit()
            finally: connection.close()
            if file_sha256(target)!=root: refuse('HELD_CONTEXT_SOURCE_CHANGED')
            connection=sio.sqlite_connect(db.as_uri()+'?mode=ro',uri=True)
            try:
                connection.execute('PRAGMA query_only=ON'); connection.execute(f'PRAGMA cache_size=-{share}')
                self._rows[root]={'path':target,'sha256':root,'entries':reader.count,'reader':reader,'database':db,
                    'database_sha256':file_sha256(db),'connection':connection}
            except BaseException:
                connection.close()
                raise
            if self.lookup_backend!='DISK':
                from .lookup_backends import activate
                self.backend_used+=activate(self._rows[root],self.lookup_backend,self.backend_budget-self.backend_used,self.mmap_limit)
            self.stats['snapshot_bytes']+=size; self.stats['lookup_builds']+=1; self.stats['full_validations']+=1
            self.stats['prepare_seconds']+=time.perf_counter()-started
        row=self._rows[root]
        if root not in self._used or not self._active:
            self._guard(row); self._used.add(root)
        return row
    def rows(self,paths):
        return [{k:r[k] for k in ('path','sha256','entries')} for r in (self.prepare(p) for p in paths)]
    def reader(self,path): return self.prepare(path)['reader']
    def stack(self,paths):
        rows=[self.prepare(path) for path in paths]; roots=tuple(r['sha256'] for r in rows)
        if roots not in self._stacks:
            if len(set(roots))!=len(roots): refuse('HELD_DUPLICATE_VALUE_ACROSS_LEGEND_STACK')
            # Scan the smaller member of each pair; large base + tiny delta
            # requires only delta lookups, never copying the large base table.
            for i,left in enumerate(rows):
                for right in rows[i+1:]:
                    small,large=sorted((left,right),key=lambda r:r['entries'])
                    for (value,) in small['connection'].execute('SELECT value FROM lookup'):
                        if large['connection'].execute('SELECT 1 FROM lookup WHERE value=?',(value,)).fetchone():
                            refuse('HELD_DUPLICATE_VALUE_ACROSS_LEGEND_STACK')
            self._stacks.add(roots)
        return StackLookup(rows),sum(r['entries'] for r in rows)
    def verify_used(self):
        for root in sorted(self._used): self._guard(self._rows[root])
    def receipt(self):
        value={'schema':'semcrys.verified-context-receipt.v0.1','standing':'CANDIDATE_ONLY',
            'effective_configuration':self.configuration,
            'policy':'EPHEMERAL_PROCESS_OWNED_SNAPSHOTS_FULL_HASH_GUARDS',
            'operation_sequence':['ROOT_SNAPSHOT','VALIDATE_STRUCTURE','BUILD_UNIQUE_LOOKUP','HASH_GUARD_REUSE','VERIFY_RECONSTRUCTION','HASH_GUARD_BEFORE_PUBLISH'],
            'legend_roots':sorted(self._rows),'stats':dict(self.stats),'persistent_cache':False,
            'lookup_cache':self.lookup_cache.receipt(),
            'sqlite_cache_targets':{'connections':len(self._rows),'per_connection_kib':self._sqlite_share_kib,
                'aggregate_kib':len(self._rows)*self._sqlite_share_kib,'budget_kib':self.sqlite_cache_budget_kib,
                'hard_process_memory_limit':False},
            'artifact_bytes_changed':False,'security_claim':'NONE'}
        if self.lookup_backend!='DISK':
            value['physical_lookup']={'backend':self.lookup_backend,'rows':[r['backend'] for r in self._rows.values()],
                'payload_estimate_bytes':self.backend_used,'hard_rss_limit':False}
        return {**value,'receipt_sha256':hashlib.sha256(canonical(value)).hexdigest()}
