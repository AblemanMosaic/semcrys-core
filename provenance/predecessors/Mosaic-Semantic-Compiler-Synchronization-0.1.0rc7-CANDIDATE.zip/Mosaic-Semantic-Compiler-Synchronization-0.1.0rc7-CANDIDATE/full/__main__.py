from semcrys.cli import main
raise SystemExit(main())
