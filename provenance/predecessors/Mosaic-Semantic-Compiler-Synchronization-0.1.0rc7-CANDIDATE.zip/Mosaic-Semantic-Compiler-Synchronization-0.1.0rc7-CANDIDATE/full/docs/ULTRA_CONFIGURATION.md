# Ultra legend: configuration and measured results

The Ultra family legend is distributed as a `.crys` container and restored
before use.

    semcrys decode ULTRA_FAMILY.crys ultra.leg

| property | value |
|---|---|
| container sha256 | `859f1160b2c61620fc582d6d420294d91d6d68106f67e97ac14930e69bbb4e71` |
| container bytes | 22,939,848 |
| restored legend bytes | 54,102,082 |
| restored legend sha256 | `4e837160f1d0f3ccf1d568e01592286dbe0d982f862f0191db1d570f7b36d6b4` |

## The outer codec is not applied by default

Encoding against a pre-shared legend does **not** apply an outer codec unless
one is requested. On Pride and Prejudice (717,602 bytes, sha256
`441e778a4297bfc944dc254810e8ded3134cfb0e36d73eef6bb312b4ffd74d6a`) under `T:PRESHARED_TOKEN`:

| configuration | container bytes | ratio |
|---|---|---|
| default (`--outer NONE`) | 416,852 | 0.581 |
| `--outer LZMA` | **200,520** | **0.279** |
| `xz -6` on the source | 210,860 | 0.294 |

Both round-trip byte-identically. The published 200,520 figure — a 4.9%
improvement on the baseline — is the `--outer LZMA` configuration. The default
configuration loses to the baseline by 98%.

    semcrys encode book.txt book.crys \
        --profile T:PRESHARED_TOKEN --legend ultra.leg --outer LZMA

## Hash provenance

Every digest on this page was read from `sha256sum` output on the actual
artifact, not transcribed from a truncated display. The container digest
published before this revision was wrong: it shared only its first four bytes
with the real value, because the remainder had been filled in rather than
measured. The payload was never affected — the container's internal roots,
`verify-self`, and the restored-legend digest were all correct and
self-consistent throughout — but a published integrity claim was not.

The Ultra container is distributed separately and is not a member of this
package, so no test in this repository can check the digest above
automatically. It must be re-read from the artifact whenever this page changes.

## Reporting rule

No ratio is published without the configuration that produced it. A figure
quoted without its `--outer` setting, legend root, and profile is not a claim
this project makes.
