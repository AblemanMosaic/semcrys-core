# SemCrys v0.1.0rc1 release-candidate status

Prepared and documentation-reviewed: 2026-08-31.

This package is technically prepared for independent whole-application review.
It is not an authorized public release, admission, production deployment, or
publisher-authentication claim.

## Established locally

- The `.crys` 0.2, binary `.leg` 0.2, and `.gly` 0.1 formats remain rooted and
  fail closed on unsupported critical configuration.
- Fifty-eight CLI leaf commands compile from the same parser used by the
  machine-readable capability surface; release-scope effects correspond exactly.
- All 79 legacy migration items have rooted explicit dispositions.
- Applicable predecessor and successor source regression suites pass.
- The wheel and zipapp are built twice offline and must be byte-identical.
- The zipapp and an isolated wheel installation must pass `verify-self`,
  capability/format/workbench correspondence, exact round trips, typed refusal,
  and package-inventory checks before a distribution receipt can pass.

## Not established

No global compression optimum, unseen-workload prediction, arbitrary option
product, universal RSS/scale bound, power-loss atomicity, cross-OS/network lock
interoperability, or cryptographic confidentiality is claimed. No private
legend, model, dataset, Python runtime, or network service is bundled.

Independent acceptance and public publication remain separate acts. Exact
artifact hashes establish correspondence, not publisher identity when an
attacker can replace both payload and manifest.
