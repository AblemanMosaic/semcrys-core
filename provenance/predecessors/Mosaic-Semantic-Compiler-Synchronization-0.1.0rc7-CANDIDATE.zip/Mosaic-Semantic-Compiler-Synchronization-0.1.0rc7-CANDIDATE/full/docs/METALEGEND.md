# Multi-document metalegends — candidate application

`semcrys metalegend pack OUTDIR --source a.crys --source b.crys`
creates a new directory containing archive.crys and META_RECEIPT.json.
EXTERNAL placement also writes meta.leg. Default MIN_TOTAL/AUTO compares
META and VERBATIM controls with NONE and LZMA2/XZ-preset6 outer encoding.
It chooses the smallest complete bundle, original control/NONE first on ties.
Explicit --selection META and --placement EXTERNAL are available.

`semcrys metalegend unpack archive.crys OUTDIR [--meta meta.leg]`
restores exact original .crys artifacts and exact external .leg dependencies.
Then the ordinary application decoder verifies each restored source.
It publishes only after all inverses pass. Both destinations must be new
directories. Input names are not extraction paths: ordinal safe filenames
are generated. Original filenames/person identities are not preserved.

This is the historical SCA-META-01 mechanism generalized to exact stored
legend records: one sorted pool, plus a local-ID-to-meta-ID map for each
distinct original legend. The original header, sparse-index stride and
stored program bytes reconstruct the original .leg hash, not just its text.
Form and pair references stay in their original local namespaces. Equal
program bytes can be pooled without asserting equivalent meaning.
Container templates replace only embedded LEGD payloads with recipe indices;
every other byte, including receipts and ancillary sections, is retained.

The binary .leg v0.2 pool has unit_mode META_RECORDS_V1. The existing .crys
envelope has one META binding, embedded or external, and an explicit critical
semcrys.metalegend-instance.v0.1 configuration. Its decoded root is the
canonical restored-artifact inventory root; each inventory row binds kind,
exact bytes and SHA-256. This is an archive object, not a single text stream.
Ordinary decode refuses with HELD_META_REQUIRES_UNPACK; older readers refuse
the unknown critical configuration.

S: cross-document record pooling is distinct from within-document pair
fractionation, shared base-legend use, statistical compression and encryption.
CM1: at least two verified source containers, exact complete dependency set,
valid local namespace reconstruction, explicit format/resource limits.
CM2: complete bundle costs, pooled versus verbatim controls under the same
outer-codec choices. Archive-only cost is separately reported, conditional on
the exact external metalegend already being shared; it is not proof of state.
IC: rooted ordered source/dependency manifest, mode, placement, pool identity,
limits and operation sequence. IR: actual candidate measurements and inverses.

In the compatible BODY_ONLY layout, LZMA compresses BODY, leaving the pool
outside the compressor. WHOLE_BUNDLE instead writes an explicitly typed .crys
envelope whose BODY compresses the complete embedded inner archive. That
includes the pool, original-legend reconstruction recipes and control fields.
AUTO compares both layouts where admissible; --placement AUTO compares both
embedded and external body-only layouts too. Defaults retain BODY_ONLY for
compatibility. Existing destinations and arbitrary recursive archives refuse.

Example: `semcrys metalegend pack OUT --source a.crys --source b.crys --layout AUTO --placement AUTO`.
All alternatives reconstruct before selection. WHOLE_BUNDLE requires embedded
placement and LZMA; its inner archive uses NONE, avoiding double compression.
Its outer envelope and audit receipt are not compressed or counted as free.

--accounting COLD charges archive plus external pool once. --accounting WARM
omits an external pool only when --receiver-root supplies that exact candidate
pool hash. Omitted, malformed, duplicate or unrelated declarations cannot earn
unexplained savings. WARM without roots still pays full cost. Receiver roots
are caller declarations, not authentication or proof of actual possession.
selected_total_bytes always retains full cold cost; selected_delivery_bytes
is the accounting-sensitive objective. The audit receipt is separate.

--shared-pool established.leg reuses an exact META_RECORDS_V1 pool, preserving
its bytes and ID order. Supersets are allowed, enabling another document set
to reuse the same pool. Missing records or the wrong type refuse; there is no
implicit append, overwrite or adoption. A warm output directory still includes
the pool for inspection, but the receipt identifies its separately accounted
dependency; blindly sending the whole directory is not the claimed wire cost.

Bounds: 32 documents, 1024 distinct legend recipes, one million aggregate
legend records, 64 MiB source-container bytes, 64 MiB external-legend bytes,
160 MiB raw archive body, 128 MiB restored artifacts. The implementation is
streamed for container literals and pooled record payloads (Court047): literal
file spans copy in at most 1 MiB blocks, and byte-sorted pool/index data uses a
private SQLite database with a 256 MiB page ceiling and 2 MiB cache target.
File spans bind a digest of their exact byte range and recheck while copying.
Timestamps are only early refusal signals, not proof of unchanged content.
The local request IC records these controls; archive bytes and final IC are
unchanged. Recipe/header and artifact descriptors remain bounded in memory.
Cache targets are not hard RSS caps. Court049 adds --max-scratch-bytes to pack
and unpack (default 4 GiB, integer range 0 through 1 TiB). One private operation
scope reserves logical file growth before writes and full enforced SQLite page
capacity before native builders open. Nested capture/verification/index spools
share that scope. Unsupported SQLite temporary-B-tree plans refuse, rather than
spilling outside accounting. This is conservative capacity reservation, not
physical filesystem allocation or a RAM limit. All audit-file writes are charged;
the receipt snapshot is explicitly before final audit serialization/publication.
Insufficient budget refuses without publishing a new output directory.
The local request carries the policy; transported configurations and selected
archive bytes do not depend on the budget when the same alternatives complete.
This is not an OS sandbox or enforcement over arbitrary unregistered code.
Combined maxima, power-loss durability and cross-platform behavior remain unqualified.
No crypto hooks are silently activated.

Restoration also caps each recipe's exact serialized byte size before writing
mapped values, and caps aggregate recipe bytes separately from output artifacts.
These limits are not an operating-system peak-RSS or temporary-disk certificate.

Supported inputs include ordinary packed, local/shared/longitudinal form
assemblies, composed second-pass containers, raw profiles and embedded glyph
containers. External glyph/fold auxiliary dependencies and nested metalegend
archives are typed unavailable. Existing batch-encode remains a separate
shared-context workflow, not an implicit metalegend constructor.

All original container/legend bytes count in the flat-file baseline; each
external dependency counts once. Archive total is .crys plus its external
meta.leg when applicable. Local audit receipts are reported separately and
not called free. Reduced archive-only delivery is not necessarily reduced
total storage. No encoding, withholding or dispersion result is a
cryptographic confidentiality claim. No canonical CSIL/GTK identity changes.
# Final resource accounting and recovery

Public pack/unpack use one directory owner for nested codec work, final payloads,
internal realization receipts, a self-counted LOCAL_RESOURCE_RECEIPT.json and a
reserved 256 KiB recovery journal. They publish only to absent destinations.
The public receipt_sha256 roots the final return, while
realization_receipt_sha256 roots the internal META_RECEIPT.json or
UNPACK_RECEIPT.json. These local audit files are not decoder dependencies or free
transport bytes. Existing candidate cost rows keep their declared cold/warm basis.

Prepared/published interruptions retain the rooted journal for explicit
directory-inspect and directory-quarantine. See DIRECTORY_RESOURCES.md for exact
target/root authorization, limits, and the required stopped-writer precondition.
No power-loss durability, concurrent-writer isolation or security claim follows.
# External glyph and folded-front dependencies (dev62)

The former external-auxiliary refusal is superseded only by the explicit typed
v0.2 path in `META_AUXILIARIES.md`. Supply required `--glyph` and `--fold-front`
artifacts to pack; they are restored byte-for-byte and passed to the exact source
decoders. Ordinary v0.1 archives and their bytes are unchanged. Nested archives
remain refused. No confidentiality or admission claim follows from this addition.
