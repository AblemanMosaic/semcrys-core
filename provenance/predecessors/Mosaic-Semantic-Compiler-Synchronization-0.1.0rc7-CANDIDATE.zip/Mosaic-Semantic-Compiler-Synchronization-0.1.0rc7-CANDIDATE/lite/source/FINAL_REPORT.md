# SemCrys-Lite 0.1.0rc5 synchronization report

rc5 preserves the rc4 byte and word reference dialect while repairing three
measurement/configuration defects: frequency ties now use lexical ordering;
caller-supplied legends default external; and cold accounting charges actual
canonical legend artifacts. The CLI now matches the documented binary packed-
varint default. Permanent regressions raise the source court to 178 tests.

The release documents describe byte and word profiles, adjacent-pair assemblies,
the L0–L3 recurrence-placement ladder, binary/text envelopes, packed/JSON event
bodies, exact artifact accounting, and observed disclosure without stale rc3
claims. Historical unrooted cold benchmark numbers are explicitly superseded.

A shared event-model contract and dialect crosswalk connect Lite to full SemCrys
at the role level. They prohibit silent ABI identity. Full SemCrys gains read-only
disclosure, deterministic ordering-projection, packed-cost composition-proposal,
and actual-artifact amortization surfaces.

Standing: `CANDIDATE_ONLY`. Independent acceptance: false. Security claim: `NONE`.
