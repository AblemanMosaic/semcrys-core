# Governed tutorial corpus

`SCENARIOS.json` describes six bounded lessons: repeated text, arbitrary bytes,
identical messages, equal-length different messages, longitudinal legend
growth, and wrong-key/tampered-companion refusal. The expected observations are
questions about public equality and custody—not security conclusions.

Run `python -m semcrys_lite demo` for the executable repeated-text lesson.
Use `compare FILE --key-file KEY` to apply the five projections to your own
input. The tutorial key used by `demo` is public and must never be reused.
