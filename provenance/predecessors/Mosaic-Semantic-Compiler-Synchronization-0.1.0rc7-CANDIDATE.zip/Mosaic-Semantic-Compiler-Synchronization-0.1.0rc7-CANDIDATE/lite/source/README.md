# SemCrys-Lite 0.1.0rc5 — Candidate

SemCrys-Lite is the auditable reference member of the Mosaic Semantic Compiler
Suite. It turns arbitrary bytes—or lossless word/separator units—into rooted
integer events and reconstructs the source exactly. Its small Python surface
makes event identity, legend placement, assembly expansion, occurrence
topology, and physical carriers inspectable.

Lite is an executable specification, teaching tool, mechanism-isolation court,
and universal byte fallback. Full SemCrys is the performance member: it owns
large binary legends, streaming, richer assembly families, and governed profile
selection. Their roles correspond through `EVENT_MODEL_CONTRACT.json`; their
container and legend ABIs are deliberately distinct.

## Quick start

```powershell
python -m semcrys_lite encode input.bin output.crys
python -m semcrys_lite decode output.crys restored.bin
python -m semcrys_lite inspect output.crys --body
python -m semcrys_lite demo
python -m semcrys_lite compare input.bin
```

The default is a binary envelope carrying packed varints. Request
`--envelope TEXT --body-representation JSON_EVENTS` for the deliberately larger
human-readable teaching form. `--outer LZMA` is an additional physical carrier;
it does not change the logical event model.

## Pre-shared and word profiles

```powershell
python -m semcrys_lite legend universal.leg --universal-bytes
python -m semcrys_lite encode input.bin output.crys --profile L:BYTE_PRESHARED --legend universal.leg
python -m semcrys_lite decode output.crys restored.bin --legend universal.leg

python -m semcrys_lite legend base.leg --source corpus.txt --words
python -m semcrys_lite assembly phrases.leg --base base.leg --corpus corpus.txt
python -m semcrys_lite encode doc.txt doc.crys --profile L:WORD_ASSEMBLY --legend base.leg --assembly-legend phrases.leg --outer LZMA
```

Caller-supplied legends default to `EXTERNAL`; a legend constructed during the
encode defaults to `SELF_CONTAINED`. Frequency ordering uses lexical tie breaks,
so equal counts do not inherit incidental source order.

`account` and `corpus` charge the exact canonical `.leg` artifact bytes. They do
not substitute a hypothetical compressed legend. `disclosure` measures observed
frequency/introduction/vocabulary exposure. `ladder` shows recurrence-placement
rungs.

Bounded-alias and full-unique moving legends require the optional established
AES-256-GCM backend and at least 32 bytes of runtime key material. The key is not
recorded. These are mechanism experiments, not a proved secure protocol.

Standing: `CANDIDATE_ONLY`. Security claim: `NONE`.
