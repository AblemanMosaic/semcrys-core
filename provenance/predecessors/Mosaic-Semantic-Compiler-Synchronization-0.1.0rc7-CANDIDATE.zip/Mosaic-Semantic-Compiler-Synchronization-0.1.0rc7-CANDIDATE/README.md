# SemCrys Lite/full synchronization candidate

This successor synchronizes the two applications around a shared logical event
contract while retaining separate `.crys` and `.leg` ABIs.

- `lite/source` is the SemCrys-Lite 0.1.0rc5 source candidate.
- `full` is the full SemCrys rc1 application with an additive read-only
  synchronization measurement surface.
- `shared` contains the event contract and dialect crosswalk.
- `evidence` contains rooted test, convergence, and package records.
- `tools/run_review.py` reproduces the clean-process review records.

Nothing here is admitted or released. Security claim remains `NONE`.

## Reproducing the evidence

    python3 tools/run_review.py 1
    python3 tools/run_review.py 2

Review records are host-independent: the interpreter path is normalized before
the record is rooted, so `review_root` reproduces on any platform over the same
frozen subject. Host detail is retained in a non-rooted `environment_not_rooted`
block.

## Fixtures versus evidence

`fixtures/accounting-size-stub.crys` is a size stub for `synchronize account`
and is not decodable; see `fixtures/README.md`. Nothing under `evidence/`
implies a capability it does not have.

